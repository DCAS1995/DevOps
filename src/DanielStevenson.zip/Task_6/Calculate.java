package Task_6;

public interface Calculate {
	void execute();
}
