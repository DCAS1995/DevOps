
public class Task_10 {

}
