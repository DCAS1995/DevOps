
public class Task_1 {
	public static void main(String[] args) {
		for(int n=0; n<10; n++){
			for(int m=0; m<n+1; m++){
				System.out.print("*");
			}
			System.out.println("");
		}
	}
}
